const express = require('express');
const mysql = require('mysql2');
const bodyParser = require('body-parser');

const app = express();
const port = 3000;

// Middleware
app.use(bodyParser.json());

// MySQL connection
const db = mysql.createConnection({
    host: 'localhost',
    user: 'root',  
    password: 'root', 
    database: 'bookdb'
});

db.connect(err => {
    if (err) {
        console.error('Database connection failed:', err.stack);
        return;
    }
    console.log('Connected to database.');
});

// Create a new book
app.post('/books', (req, res) => {
    const { title, author, isbn, publication_date } = req.body;
    const query = 'INSERT INTO books (title, author, isbn, publication_date) VALUES (?, ?, ?, ?)';
    db.query(query, [title, author, isbn, publication_date], (err, results) => {
        if (err) {
            res.status(500).send(err);
            return;
        }
        res.status(201).json({ id: results.insertId, title, author, isbn, publication_date });
    });
});

// Read all books
app.get('/books', (req, res) => {
    const query = 'SELECT * FROM books';
    db.query(query, (err, results) => {
        if (err) {
            res.status(500).send(err);
            return;
        }
        res.status(200).json(results);
    });
});

// Read a single book
app.get('/books/:id', (req, res) => {
    const { id } = req.params;
    const query = 'SELECT * FROM books WHERE id = ?';
    db.query(query, [id], (err, results) => {
        if (err) {
            res.status(500).send(err);
            return;
        }
        if (results.length === 0) {
            res.status(404).send('Book not found');
            return;
        }
        res.status(200).json(results[0]);
    });
});

// Update a book
app.put('/books/:id', (req, res) => {
    const { id } = req.params;
    const { title, author, isbn, publication_date } = req.body;
    const query = 'UPDATE books SET title = ?, author = ?, isbn = ?, publication_date = ? WHERE id = ?';
    db.query(query, [title, author, isbn, publication_date, id], (err, results) => {
        if (err) {
            res.status(500).send(err);
            return;
        }
        if (results.affectedRows === 0) {
            res.status(404).send('Book not found');
            return;
        }
        res.status(200).send('Book updated successfully');
    });
});

// Delete a book
app.delete('/books/:id', (req, res) => {
    const { id } = req.params;
    const query = 'DELETE FROM books WHERE id = ?';
    db.query(query, [id], (err, results) => {
        if (err) {
            res.status(500).send(err);
            return;
        }
        if (results.affectedRows === 0) {
            res.status(404).send('Book not found');
            return;
        }
        res.status(200).send('Book deleted successfully');
    });
});

app.listen(port, () => {
    console.log(`Server running on http://localhost:${port}`);
});
